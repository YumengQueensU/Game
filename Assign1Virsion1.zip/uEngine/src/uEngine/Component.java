package uEngine;

/**
 * 
 * @author Nicholas Graham
 * 
 */
public class Component {
	// The parent game object that this component is attached to
	private GameObject gameObject;
	public Component() {
		// I need to define this otherwise there will be a bug in the child class file of Component.java, such as the Transform.java.
	}
	public Component(GameObject gameObject) {
		this.gameObject = gameObject;//This is easy haha
	}
}
