package uEngine;


public class GameObject {
	public String id = super.toString();
	public String name;
	
	// These are default components
	public Transform transform;
	public Material material;
	public AudioEngine audio; 
	// What data structure should be used for components provided by the game programmer?
	// Adds a new component to this game object
	public void AddComponent(Component c) {
		// ...
       
	}
	
	public Game game;
	
	public void start() {}
	public void update(float elapsedTime) {}
	public void onCollisionEnter(GameObject col) {}
	public void onCollisionExit(GameObject col) {}
	
	public String toString() {
		return name + ": " + transform;
	}
	
	public GameObject() {		
		// Create default components
		// ...
		
		// Name normally provided by programmer
        this.id = super.toString();
        transform = new Transform();
        material = new Material();
        audio = new AudioEngine();
		name = "";
	}
}
