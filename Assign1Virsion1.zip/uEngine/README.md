# uEngine-stripped
uEngine template code for CISC 486/877

This is starter code for assignment 1. When you create your own repository, it will contain this starter code. See OnQ for a detailed description of the assignment.
